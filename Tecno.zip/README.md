
# Analisis de ventas para la empresa TechData

---

## Contexto de la empresa:

TechData posee sedes en 5 ciudades en Colombia: Santa Marta, Barranquilla, Cartagena, Monteria y Bogotá, en la sede principal ubicada en Barranquilla, el  equipo de contabilidad manejaba las ventas en un solo excel, ademas de eso, la forma de escritura de los datos era inconsistente con los tipos de los datos, tambien varios registros poseian valores nulos o tenian un duplicado, teniendo este problema la empresa TechData recurre a mi persona para realizar la limpieza y la creacion de una base de datos para el correcto almacenamiento de los datos, como plus, realizare un analisis del negocio de TechData para entregarles un informe de como van con sus KPIs y OKRs
